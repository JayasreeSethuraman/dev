PROJECT: Learning And Development (LAND)

VERSION: node > 7.5

INIT:
    Node command for init: "npm init"

        init command is used to set up a new or existing npm package

START:
    Node command for start: "npm run start"

        Checks for programming styles and conventions and
        Runs the app in development mode.
        
        Open http://localhost:8080 to view it in the browser.

        The page will automatically reload if you make changes to the code.

BUILD:
    Node command for build: "npm run build"

        Builds the app for production to the dist folder.

        It first checks for programming styles and conventions and bundles the application files in production mode
        and optimizes the build for the best performance.

        The build is uglified and bundled.

SERVE:
    Node command for serve: "npm run serve"

        Runs the app in development mode.
        Open http://localhost:8080 to view it in the browser.

        The page will automatically reload if you make changes to the code.

LINT:
    Node command for lint: "npm run lint"

        Set of guidelines which checks developer's source code 
        for programming styles and conventions
        
TEST:
    Node command for test: "npm run test"

        It will run all the test files that are defined for the application and 
        gives the report of the test with code coverage information
