var OFF = 0, WARN = 1, ERROR = 2;

module.exports = {
    "extends": "airbnb",
    "rules": {
        "linebreak-style": [WARN, "unix"],
        "react/jsx-filename-extension": [1, { "extensions": [".js", ".jsx"] }],
        "import/no-named-as-default": 0,
        "import/no-named-as-default-member": 0
    },
    "env": {
        "browser": true,
        "es6": true,
        "node": true
    },
    "globals": {
      "document": false
    }
};