var personInfoPanel = {};
personInfoPanel.view;
var keys = ['id', 'firstname', 'lastname', 'email', 'birthday', 'isadmin'];
var submitPerson = {};
submitPerson.person = {};

personInfoPanel.createChildren = function () {};

personInfoPanel.createView = function () {
    personInfoPanel.view = doReadHtml('personInfoPanel', personInfoPanel.view);
};

personInfoPanel.prePopulate = function () {};

personInfoPanel.listenEvents = function () {
    document.getElementById('submit').addEventListener('click', onSubmitSelect);
    document.getElementById('reset').addEventListener('click', onResetSelect);
    eventManager.subscribe('listSelected', onSelectList);
    eventManager.subscribe('addSelected', onSelectAdd);
    eventManager.subscribe('deleteSelected', onSelectDelete);
};

personInfoPanel.setDefault = function () {};

var onSubmitSelect = function () {
    for (var index = 0; index < keys.length; index++) {
        submitPerson.person[keys[index]] = document.getElementById(keys[index]).value;
    }
    manageEvent('submit', submitPerson);
};

var onResetSelect = function () {
    manageEvent('reset', '');
};

var onSelectList = function (row) {
    for (var index = 0; index < row.cells.length; index++) {
        document.getElementById(keys[index]).value = row.cells[index].innerHTML;
    }
    rowNumber = row.id;
    console.log(rowNumber);
};

var onSelectAdd = function () {
    for (var index = 0; index < keys.length; index++) {
        document.getElementById(keys[index]).value = '';
    }
    document.getElementById(keys[1]).focus();
    isListCreate = true;
};

var onSelectDelete = function () {
    
};
