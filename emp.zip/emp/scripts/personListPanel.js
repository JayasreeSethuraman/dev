var personListPanel = {};
personListPanel.view;
var person;
var listTemplate;
var isListCreate;
var rowNumber;
var index = -1;

personListPanel.createChildren = function () {};

personListPanel.createView = function () {
    personListPanel.view = doReadHtml('personListPanel', personListPanel.view);
};

personListPanel.prePopulate = function () {
    doRead();
    createTemplate();
    constructList(person);
};

personListPanel.listenEvents = function () {
    document.getElementById('add').addEventListener('click', onAddSelect);
    for (var index = 0; index < person.length; index++) {
        document.getElementById('row' + index).addEventListener('click', onListSelect);
        document.getElementById('delete' + index).addEventListener('click', onDeleteSelect);
    }
    eventManager.subscribe('submit', onSubmit);
};

personListPanel.setDefault = function () {
    document.getElementById('row0').click();
};

var onAddSelect = function () {
    manageEvent('addSelected', '');
};

var onListSelect = function () {
    manageEvent('listSelected', this);
};

var onSubmit = function (submitPerson) {
    if (true === isListCreate) {
        var list = document.getElementById('personList');
        index = list.rows.length;
        constructList(submitPerson);
        return;
    }
    
};

var onDeleteSelect = function () {
    
};

var doRead = function () {
    person = doReadResource('person', person);
};

var createTemplate = function () {
    listTemplate = doReadHtml('personListTemplate', listTemplate);
};

var constructList = function (personList) {
    var listItem = '';
    for (per in personList) {
        index += 1;
        var values = Object.values(personList[per]);
        listItem += listTemplate.replace(/%rowId%/, 'row' + index)
                                .replace(/%id%/, values[0])
                                .replace(/%firstname%/, values[1])
                                .replace(/%lastname%/, values[2])
                                .replace(/%email%/, values[3])
                                .replace(/%birthday%/, values[4])
                                .replace(/%isadmin%/, values[5])
                                .replace(/%delete%/, 'delete' + index);
    }
    document.getElementById('personList').innerHTML += listItem;
};
