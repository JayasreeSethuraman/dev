var eventManager = {};

var listener = [];

eventManager.subscribe = function (eventName, action) {
    listener[eventName] = action;
};

eventManager.broadcast = function (eventName, param) {
    var handler = listener[eventName];
    handler(param);
};
