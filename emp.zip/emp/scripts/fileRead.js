var doReadHtml = function (fileName, panelView) {
    var path = 'html/' + fileName + '.html';
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            panelView = this.responseText;
        }
    };
    xhttp.open('GET', path, false);
    xhttp.send();
    return panelView;
};

var doReadResource = function (fileName, entity) {
    var path = 'assets/' + fileName + '.json';
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            entity = JSON.parse(this.responseText);
        }
    };
    xhttp.open('GET', path, false);
    xhttp.send();
    return entity;
};

