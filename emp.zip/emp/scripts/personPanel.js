var personPanel = {};
personPanel.view;
var createPersonPanel = function () {
    personPanel.view = doReadHtml('personPanel', personPanel.view);
};
personPanel.init = function () {
    personPanel.createChildren();
    personPanel.createView();
    personPanel.prePopulate();
    personPanel.listenEvents();
    personPanel.setDefault();
};

personPanel.createChildren = function () {
    personListPanel.createChildren();
    personInfoPanel.createChildren();
};

personPanel.createView = function () {
    personListPanel.createView();
    document.getElementById('personPanel').innerHTML = personListPanel.view;
    personInfoPanel.createView();
    document.getElementById('personPanel').innerHTML += personInfoPanel.view;
};

personPanel.prePopulate = function () {
    personListPanel.prePopulate();
    personInfoPanel.prePopulate();
};

personPanel.listenEvents = function () {
    personListPanel.listenEvents();
    personInfoPanel.listenEvents();
};

personPanel.setDefault = function () {
    personListPanel.setDefault();
    personInfoPanel.setDefault();
};
