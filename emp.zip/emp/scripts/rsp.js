var rsp = {};
rsp.view;

rsp.createChildren = function () {};

rsp.createView = function () {
    rsp.view = doReadHtml('rsp', rsp.view);
};

rsp.prePopulate = function () {};

rsp.listenEvents = function() {
    eventManager.subscribe('entitySelected', onSelectEntity);
};

rsp.setDefault = function () {};

var onSelectEntity = function (entity) {
    if ('person' === entity) {
        createPersonPanel();
        document.getElementById('rsp').innerHTML = personPanel.view;
        personPanel.init();
    }
    if ('address' === entity) {
        addressPanel.init();
    }
};
