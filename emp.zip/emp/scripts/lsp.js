var lsp = {};
lsp.view;

lsp.createChildren = function () {};

lsp.createView = function () {
    lsp.view = doReadHtml('lsp', lsp.view);
};

lsp.prePopulate = function () {};

lsp.listenEvents = function () {
    document.getElementById('personSelect').addEventListener('click', onPersonSelect);
    document.getElementById('addressSelect').addEventListener('click', onAddressSelect);
};

var manageEvent = function (eventName, data) {
    eventManager.broadcast(eventName, data);
};

lsp.setDefault = function () {
    manageEvent('entitySelected', 'person');
};

var onPersonSelect = function () {
    manageEvent('entitySelected', 'person');
};

var onAddressSelect = function () {
    manageEvent('entitySelected', 'address');
};
